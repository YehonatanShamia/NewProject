package com.example.project;

public class dropObject {
    private char [] arr8 = new char[8];
    private int y ;

}
