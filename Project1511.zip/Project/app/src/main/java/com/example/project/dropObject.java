package com.example.project;

public class dropObject {
    private char [] arr = new char[8];
    private int y ;

    public dropObject(char[] arr, int y) {
        this.arr = arr;
        this.y = y;
    }
    public void droppingObject(){
        y -= 10;
    }
}
